#!/usr/bin/env python3
"""Phase A - chain-of-custody manifest (read-only on originals/)."""
import csv, hashlib, os, datetime as dt, getpass
WAT = dt.timezone(dt.timedelta(hours=1))
files = ["dataset_small.csv","dataset_train.jsonl","dataset_test.jsonl","result.csv","fine_tuning_steps.txt"]
rows = [("IP_Identifier_Fine_Tuning.zip", "originals/IP_Identifier_Fine_Tuning.zip", "ICDFA-supplied package (E-Campus)")] + \
       [(f, "originals/" + f, "extracted from IP_Identifier_Fine_Tuning.zip -> code/" + f) for f in files]
now = dt.datetime.now(dt.timezone.utc)
with open("results/evidence_manifest.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["filename","sha256","size_bytes","hashed_utc","hashed_wat","transfer_source","examiner"])
    for name, path, src in rows:
        h = hashlib.sha256(open(path, "rb").read()).hexdigest()
        w.writerow([name, h, os.path.getsize(path), now.strftime("%Y-%m-%dT%H:%M:%SZ"), now.astimezone(WAT).strftime("%Y-%m-%dT%H:%M:%S+01:00"), src, getpass.getuser()])
print(open("results/evidence_manifest.csv").read())
