# CIP-B107-LAB01 reproduction (Zeeshan Sajid, 17313)
Environment: Kali Linux, python3 -m venv --system-site-packages venv; versions in pip_freeze_relevant.txt.
Put the 5 source files (dataset_small.csv, dataset_train.jsonl, dataset_test.jsonl, result.csv, fine_tuning_steps.txt) and IP_Identifier_Fine_Tuning.zip in originals/, create results/, then run in order:
manifest.py, a_profile.py, b_candidates.py, c_model.py, d_history.py, e_review_sample.py (seed 42). fill_review.py holds my analyst-review wording. build_pdf.py builds the PDFs from memo.md and briefing.md.
Historical results (result.csv, fine_tuning_steps.txt) are provided teaching files, not a new run.
