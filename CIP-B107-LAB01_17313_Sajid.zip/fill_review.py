#!/usr/bin/env python3
"""Fill analyst columns in results/analyst_review.csv (DRAFT - review and edit every row before submitting)."""
import sys, pandas as pd
path = sys.argv[1] if len(sys.argv) > 1 else "results/analyst_review.csv"
d = pd.read_csv(path)
for c in ["analyst_decision", "analyst_reasoning", "escalate_to_human"]:
    d[c] = d[c].astype(object)
R = {
 8:  ("Ambiguous - likely version folder, not a confirmed address",
      "Candidate is the first four numbers of 10.5.0.1.6.137 inside a URL path (js/10.5.0.1.6.137/min/RightNow.js). It is syntactically valid IPv4, but the extra dotted numbers and the library-path context point to a software version. Source label positive is an annotation of intent, not proof.",
      "Yes - context cannot confirm an address; check surrounding records and the originating file"),
 10: ("Ambiguous - likely build/version string",
      "135.0.0.22.118 has five dotted numbers; the candidate is only the prefix. Valid IPv4 in isolation, but the trailing .118 suggests a build or version identifier. Rule baseline rejected it, ML accepted it.",
      "Yes - source/rule/ML disagree in character; needs human review"),
 21: ("Not an IP - invalid address inside an identifier",
      "Octet 256 exceeds 255 so ipaddress rejects it, and the string is part of the token tincan_register_device_256.0.1.26.113. Source label negative is correct. The ML model gave 0.66 (false positive), so it was misled by the dotted-number shape.",
      "No - but record as the ML false positive; strict validation would have caught it"),
 0:  ("Not an IP - fragment of a longer number",
      "Context is 3608.80.24.1.8; the candidate is a slice of it, preceded by an extra digit, and 608 is outside 0-255. Source negative is correct and both rule and ML agree.",
      "No"),
 19: ("Not an IP - invalid octet with trailing number",
      "257.0.1.38.116 has octet 257 (invalid) and a trailing .116. Source negative is correct; both methods agree, though the ML score (0.35) is not far from the 0.5 threshold.",
      "No - low-margin score noted"),
 15: ("IP evidence candidate",
      "Standalone tagged value <string>64.98.122.70</string>; valid IPv4, correctly bounded, and source, rule and ML all agree. Still only a candidate: nothing here shows it is routable, public, or relevant to any activity.",
      "Yes - normal corroboration step before any use as evidence"),
 9:  ("IP evidence candidate - weak, could be a version",
      "Standalone tagged value <string>20.10.0.8</string>. Valid and bounded, all three methods agree, but a bare four-part number in a configuration export can equally be a software version, so one line of context is not enough to be sure.",
      "Yes - confirm against neighbouring keys/records"),
 36: ("Ambiguous - candidate buried in a long dotted sequence",
      "Context is 5.12.20.4.10.18.5.5.2, nine dotted numbers; 10.18.5.5 is a slice from the middle. Source says positive and ML agrees, but the rule baseline rejects it and the structure looks like a version or identifier path, not an address.",
      "Yes - methods disagree and context is ambiguous"),
 17: ("IP evidence candidate - weak, could be a version",
      "Standalone tagged value <string>12.6.0.1</string>; valid, bounded, all methods agree (ML 0.86). Same caveat as 20.10.0.8: layout alone cannot separate an address from a version number.",
      "Yes - confirm against neighbouring keys/records"),
}
for i, r in d.iterrows():
    dec, why, esc = R[int(r.test_row)]
    d.loc[i, ["analyst_decision", "analyst_reasoning", "escalate_to_human"]] = [dec, why, esc]
d.to_csv(path, index=False)
print(d[["test_row", "candidate", "analyst_decision", "escalate_to_human"]].to_string())
print("blank decisions:", d.analyst_decision.isna().sum())
