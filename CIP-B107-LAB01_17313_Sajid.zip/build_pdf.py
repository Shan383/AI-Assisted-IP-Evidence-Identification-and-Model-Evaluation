#!/usr/bin/env python3
"""Usage: python3 src/build_pdf.py report/memo.md report/memo.pdf"""
import sys, markdown, weasyprint
src, out = sys.argv[1], sys.argv[2]
import pandas as pd
txt = open(src, encoding="utf-8").read()
if "@@MANIFEST@@" in txt:
    m = pd.read_csv("results/evidence_manifest.csv")
    m["sha256"] = m["sha256"].str[:20] + "..."
    txt = txt.replace("@@MANIFEST@@", m[["filename","sha256","size_bytes","hashed_wat"]].to_markdown(index=False))
if "@@REVIEW@@" in txt:
    a = pd.read_csv("results/analyst_review.csv")
    t = a[["test_row","candidate","actual","ml_predicted","rule_predicted","analyst_decision","escalate_to_human"]]
    txt = txt.replace("@@REVIEW@@", t.to_markdown(index=False))
html = markdown.markdown(txt, extensions=["tables", "fenced_code"])
css = """@page { size: A4; margin: 18mm; @bottom-center { content: "CIP-B107-LAB01 | Page " counter(page); font-size: 8pt; color: #555; } }
body { font-family: 'DejaVu Sans', sans-serif; font-size: 9.5pt; line-height: 1.4; }
h1 { font-size: 16pt; } h2 { font-size: 12pt; border-bottom: 1px solid #999; padding-top: 6pt; }
table { border-collapse: collapse; width: 100%; font-size: 8.5pt; } th, td { border: 1px solid #999; padding: 3pt 5pt; vertical-align: top; }
th { background: #eee; } code { font-size: 8pt; } img { max-width: 100%; }"""
weasyprint.HTML(string=f"<style>{css}</style>{html}", base_url=".").write_pdf(out)
print("wrote", out)
