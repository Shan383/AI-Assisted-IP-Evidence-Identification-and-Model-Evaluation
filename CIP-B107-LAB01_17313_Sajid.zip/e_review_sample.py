#!/usr/bin/env python3
"""Phase E - build the 8+ record analyst-review worksheet from predictions.csv (you fill the analyst columns by hand)."""
import pandas as pd
p = pd.read_csv("results/predictions.csv")
errs = p[(p.tfidf_logreg_outcome.isin(["FP","FN"])) | (p.rule_regex_ipaddress_outcome.isin(["FP","FN"]))]
negs = p[(p.actual == "negative")].drop_duplicates("candidate")
poss = p[(p.actual == "positive") & (p.ml_score.between(0.0, 1.0))].sort_values("ml_score").drop_duplicates("candidate")
pick = pd.concat([errs.drop_duplicates("candidate").head(3), negs.head(3), poss.head(3), poss.tail(1)]).drop_duplicates("test_row").head(10)
pick = pick.assign(analyst_decision="", analyst_reasoning="", escalate_to_human="")
pick.to_csv("results/analyst_review.csv", index=False); print(pick[["test_row","candidate","actual","ml_predicted","ml_score","rule_predicted"]].to_string())
