#!/usr/bin/env python3
"""Phase B - regex extractor + strict IPv4 validator + source label -> candidate_review.csv"""
import re, ipaddress, pandas as pd
df = pd.read_csv("originals/dataset_small.csv")

NAIVE = re.compile(r"\d{1,3}(?:\.\d{1,3}){3}")                  # loose regex, no boundaries
BOUND = re.compile(r"(?<![\d.])\d{1,3}(?:\.\d{1,3}){3}(?![\d]|\.\d)")  # regex with boundaries

def strict(s):
    try: ipaddress.IPv4Address(s); return True
    except ValueError: return False

def note(ip, text, valid, label, naive_hit, bound_hit):
    t = text.strip()
    n = []
    if re.search(r"(?<=[\d.])" + re.escape(ip) + r"|" + re.escape(ip) + r"(?=\.?\d)", t) and not bound_hit:
        n.append("suffix/prefix contamination (extra digits/dots around candidate)")
    if "http" in t: n.append("URL context")
    if re.search(r"[A-Za-z]+-[A-Za-z]+-\w*iOS-|version|rc-|/Releases/|crop\.", t, re.I): n.append("version/filename-like context")
    if len(set(NAIVE.findall(t))) > 1: n.append("one of several addresses in the string")
    if re.fullmatch(r"<string>%s</string>|<key>%s</key>" % (re.escape(ip), re.escape(ip)), t): n.append("standalone tagged value")
    if not valid: n.append("NOT valid IPv4 (octet range or leading zeros)")
    if valid and label == "negative": n.append("valid IPv4 but source says negative (disagreement kept)")
    if (not valid) and label == "positive": n.append("invalid IPv4 but source says positive (disagreement kept)")
    return "; ".join(n) if n else "auto: no flag - analyst to review"

rows = []
for i, r in df.iterrows():
    ip, text = r["ip"], r["text"]
    lab = "negative" if r["class"] == "N" else "positive"
    naive_hit = ip in NAIVE.findall(text)
    bound_hit = ip in BOUND.findall(text)
    valid = strict(ip)
    rows.append(dict(source_row=i, context=text.strip(), candidate=ip, regex_match=naive_hit,
                     ipv4_valid=valid, source_label=lab, regex_bounded=bound_hit, analyst_note=note(ip, text, valid, lab, naive_hit, bound_hit)))
out = pd.DataFrame(rows)
out = out[["source_row","context","candidate","regex_match","ipv4_valid","source_label","analyst_note","regex_bounded"]]
out.to_csv("results/candidate_review.csv", index=False)
print("saved results/candidate_review.csv", out.shape)
print("\nregex_match(naive) x regex_bounded x ipv4_valid x source_label:")
print(out.groupby(["regex_match", "regex_bounded", "ipv4_valid", "source_label"]).size().to_string())
print("\nMismatch examples (valid IPv4 but labelled negative / invalid but labelled positive):")
print(out[(out.ipv4_valid & (out.source_label == "negative")) | (~out.ipv4_valid & (out.source_label == "positive"))]
      .drop_duplicates("candidate")[["source_row", "candidate", "ipv4_valid", "source_label", "context"]].head(12).to_string())
