# Forensic Intelligence Memorandum
**Case ID:** ICDFA-DFIR-AI-026 | **Lab:** CIP-B107-LAB01 | **Examiner:** Zeeshan Sajid | **Student ID:** 17313
**Date:** @@DATE@@ | **Classification:** Controlled educational dataset (synthetic teaching data) | **Prepared for:** ICDFA review panel

## 1. Remit
I was asked to examine the supplied package `IP_Identifier_Fine_Tuning.zip`, which holds recovered text strings that may contain IP addresses. My job was to find which strings are real IP address candidates, compare a simple rule with a simple offline machine-learning model, read the provided historical fine-tuning results carefully, and report what can and cannot be trusted. Nothing in this memo shows that any address is malicious or that any system was compromised.

## 2. Evidence manifest
The original package and the five source files were hashed with SHA-256 before any analysis, made read-only (`chmod 444`) and re-checked with `sha256sum -c` (all OK). Full hashes are in `evidence_manifest.csv`. The package was collected at 2026-10-24T13:54:07Z (14:54:07 WAT). All times below are given in UTC and WAT (UTC+1).

@@MANIFEST@@

## 3. Methodology
- **Profiling:** pandas on `dataset_small.csv` (229 records with columns ip, class, text) and on the supplied JSONL split (183 train, 46 test). The split is an ordered 80/20 cut of the CSV, not a shuffle.
- **Labels:** class `N` means negative. Classes A, B, C and E are all turned into positive by the supplied preprocessing script. So "positive" means "the annotator's intended IP candidate", not "verified IP address".
- **Extraction:** a loose regex, a regex with boundaries, and a strict check using Python `ipaddress.IPv4Address`, all kept next to the source label (`candidate_review.csv`).
- **Models on the fixed holdout of 46 records:** (a) majority-class baseline, (b) rule baseline (strict IPv4 and the candidate stands alone in its text), (c) TF-IDF character n-grams plus Logistic Regression, fitted on training data only, seed 42.
- **Environment:** Kali Linux virtual environment, Python 3.14.8, pandas 2.3.3, scikit-learn 1.9.0 (see `environment.txt`).

## 4. Results

### 4.1 Evidence profile (my own analysis)
There are 229 records with no empty values, but 77 are exact duplicates and only 105 different IP strings exist. Classes are A 177, N 32, B 12, C 4 and E 4, which is 197 positive and 32 negative. Train has 163 positive and 20 negative, and test has 34 positive and 12 negative. Because many rows are copies and only about 14% are negative, the dataset is smaller and easier than "229 records" suggests, and a model sees very few examples of what is not an IP.

### 4.2 Regex, strict IPv4 check and source label (my own analysis)
The loose regex matched all 229 candidates, so a regex alone cannot tell an address from a version number. 24 rows are valid IPv4 but are stuck to more dotted digits (for example `10.5.0.1` inside `10.5.0.1.6.137`) and still labelled positive. 8 valid-IPv4 rows (for example `0.0.0.0` and `0.5.1.3`) are labelled negative. 4 rows are not valid IPv4 (for example `1.000.000.000` and `1.4.4.02`) yet labelled positive. I kept all of these and did not change any label. The strict check and the classifier answer different questions. The strict check asks, "Is this string a legal address of four numbers from 0 to 255?" The classifier asks, "Does this string, in the text around it, look like what the annotators called an IP?" For example, `10.5.0.1` is a legal address but sits inside what looks like a version folder, while `256.0.1.26` is never legal but has the shape of an address, so the model scored it 0.66 positive.

### 4.3 Holdout performance (my own new results, 46 test records)
| Model | TN | FP | FN | TP | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|---|---|---|---|
| Majority class (always positive) | 0 | 12 | 0 | 34 | 0.739 | 0.739 | 1.000 | 0.850 |
| Rule: strict IPv4 + standalone | 10 | 2 | 11 | 23 | 0.717 | 0.920 | 0.676 | 0.780 |
| TF-IDF + Logistic Regression | 11 | 1 | 0 | 34 | 0.978 | 0.971 | 1.000 | 0.986 |

The TF-IDF + Logistic Regression model scored AUROC 0.993 and AUPRC 0.997. The full actual-versus-predicted list is in `predictions.csv`.

![Confusion matrices](results/confusion_matrices.png)

**Leakage.** 30 of the 46 test rows (about 65%) also appear exactly in the training set (11 different prompts, 12 shared candidate strings). The model partly remembered answers it had already seen, so 97.8% is an upper limit and not a forecast of real-world accuracy. With only 46 test rows, one extra mistake would also move accuracy by about 2 points. Before trusting the score I would re-test on a de-duplicated, shuffled split.

**Why accuracy can mislead.** If 20 of 1,000 recovered strings were real IP evidence, a model that always says "negative" would score 98.0% accuracy and 0% recall, so it would miss every real address. On this test set the always-positive baseline already scores 73.9% without finding a single negative. In forensic triage, a missed address (false negative) means an analyst never sees a possible link to a server, victim or attacker, and the gap may never be noticed. So any ambiguous record, any middle-range score and any high-impact item must go to a human analyst, and the model must never close a record by itself.

### 4.4 Historical fine-tuning results (provided files, NOT my own model run)
These numbers come from the supplied `result.csv` and `fine_tuning_steps.txt`. I did not produce them. In the final row that has classification metrics (step 733) the file reports accuracy 0.9783, precision 0.9714, recall 1.0000, F1 0.9855, AUROC 0.9975 and AUPRC 0.9991. Only 4 of 733 rows carry these metrics, and 92 rows carry validation values. The two files give different training-loss values at the same steps (largest difference 0.30), so they are not the same log. The accuracy of 0.9783 equals 45/46, which would fit a 46-record evaluation with one false positive, but that is my own guess and the files do not say which data was used. Training loss and training accuracy are measured on the examples the model learns from, so they say nothing about performance on new data.

![Historical curves](results/historical_training_curves.png)

The old process used an "ada" fine-tuned model and old API steps (upload the file, create a job, check status, predict). Those calls belong to an older service and I cannot assume they still exist or work the same way today. I did not run the historic scripts because they depend on an outside account and key, and one of them contains a hard-coded credential, which I did not copy, display or store in my package.

## 5. Analyst review of nine holdout records
@@REVIEW@@

The full reasoning for each record is in `analyst_review.csv`. The records fall into three groups. First, three clean standalone values (`64.98.122.70`, `20.10.0.8`, `12.6.0.1`): all methods agree they look like addresses, but they are still only candidates, because a bare four-part number can also be a software version. Second, three valid addresses stuck inside longer dotted numbers (`10.5.0.1`, `135.0.0.22`, `10.18.5.5`): the source says positive, the rule says negative, and the context looks like a version or build string, so I escalated them. Third, three invalid strings (`256.0.1.26`, `257.0.1.38`, `608.80.24.1`): correctly negative. The only model error on the whole holdout was `256.0.1.26`, which the strict validator would have rejected.

## 6. Limitations
- The test set is small (46 records), so one error changes accuracy by about 2 points.
- The data has many duplicates (77 of 229 rows) and 30 of 46 test rows were already seen in training.
- The split is ordered, not shuffled, so the test set is simply the last 46 rows.
- Labels show the annotators' intent and often disagree with strict IPv4 validity. The meaning of classes B, C and E is not explained.
- The model's scores for correct positives sit between 0.64 and 0.86, so a single score should not be trusted on its own.
- The historical metrics cannot be tied to a known evaluation set, and only 4 rows have them.
- The data is synthetic teaching data, so the results may not carry over to real evidence.

## 7. Conclusion and recommendation
I recommend using this approach only as an assistant to a human analyst. The strict IPv4 check should be used for syntax. The offline model can help order records for review, but it should not decide anything by itself. The historical fine-tuning figures should be treated as unverified teaching material, not proof. No address in this review has been shown to be malicious.

## 8. Next investigative actions
1. Get the full original export and read the surrounding records for the six escalated items (`10.5.0.1`, `135.0.0.22`, `10.18.5.5`, `64.98.122.70`, `20.10.0.8`, `12.6.0.1`).
2. For any address that is confirmed as a real candidate, look for corroboration in other evidence, such as network or application logs, before treating it as relevant.
3. Re-test the model on a de-duplicated, shuffled split with more negative examples.
4. Ask the annotators what classes B, C and E mean and why glued strings such as `10.5.0.1.6.137` were marked positive.
5. Keep the strict validator as the first filter and log every case where the validator, the rule and the model disagree.

Signed: Zeeshan Sajid (Student ID 17313) | Date: @@DATE@@
