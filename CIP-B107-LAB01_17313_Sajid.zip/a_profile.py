#!/usr/bin/env python3
"""Phase A - profile evidence (read-only on originals/)."""
import json, pandas as pd
O = "originals/"
df = pd.read_csv(O + "dataset_small.csv")
print("== CSV ==")
print("records:", len(df)); print("columns:", list(df.columns))
print("\nclass distribution (source codes):\n", df["class"].value_counts().to_string())
df["label"] = df["class"].map(lambda c: "negative" if c == "N" else "positive")
print("\npositive/negative (class!=N -> positive, per preprocess_dataset.py):\n", df["label"].value_counts().to_string())
print("\nnull counts:\n", df.isna().sum().to_string())
print("\nfully duplicated rows:", df.duplicated(["ip","class","text"]).sum(),
      "| rows whose (ip,class,text) occurs more than once:", df.duplicated(["ip","class","text"], keep=False).sum())
print("unique ip values:", df["ip"].nunique())
print("ip values with conflicting labels:", int((df.groupby("ip")["label"].nunique() > 1).sum()))
print("rows with 'http' in text:", int(df["text"].str.contains("http").sum()),
      "| rows with leading-zero octets:", int(df["ip"].str.contains(r"(?:^|\.)0\d").sum()))

print("\n== JSONL ==")
def load(f):
    rows = []
    for n, line in enumerate(open(O + f, encoding="utf-8"), 1):
        try: rows.append(json.loads(line))
        except Exception as e: print(f"  INVALID JSON {f} line {n}: {e}")
    return rows
tr, te = load("dataset_train.jsonl"), load("dataset_test.jsonl")
for name, r in (("train", tr), ("test", te)):
    c = pd.Series([x["completion"].strip() for x in r]).value_counts().to_dict()
    print(f"{name}: {len(r)} valid records, class balance {c}")
print("split is 183/46:", (len(tr), len(te)) == (183, 46))
rebuilt = [(r.text + ";" + r.ip + " ->", " positive" if r["class"] != "N" else " negative") for _, r in df.iterrows()]
print("train == first 183 CSV rows (unshuffled 80/20):", [(x["prompt"], x["completion"]) for x in tr] == rebuilt[:183])
print("test  == last 46 CSV rows:", [(x["prompt"], x["completion"]) for x in te] == rebuilt[183:])

print("\n== 5 CSV rows vs prompt/completion ==")
allj = tr + te
for i in [0, 4, 61, 129, 168]:
    print(f"CSV row {i}: ip={df.ip[i]!r} class={df['class'][i]!r} text={df.text[i]!r}")
    print(f"   -> prompt={allj[i]['prompt']!r} completion={allj[i]['completion']!r}")
