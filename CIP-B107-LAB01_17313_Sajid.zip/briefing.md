# Executive Briefing - Case ICDFA-DFIR-AI-026
**Examiner:** Zeeshan Sajid (17313) | **Date:** @@DATE@@ | **Data:** synthetic teaching dataset

## The question
Can a simple AI model help an analyst pick out real IP addresses from a pile of recovered text strings?

## What I found (my own test on 46 records)
- The offline model (TF-IDF + Logistic Regression) got 45 of 46 right (97.8%) and found every positive. Its one mistake was `256.0.1.26`, which is not a valid address.
- A simple rule (valid IPv4 and standing alone) got only 71.7% and missed about a third of the positives, because the supplied labels treat many version-like strings as positive.
- Always guessing "positive" scores 73.9%, so accuracy alone is a weak measure here.
- The historical fine-tuning run reports 97.8% too, but it is not my run, its test data is not documented, and only 4 of 733 log rows carry those numbers.

## What could go wrong
- 30 of the 46 test records were already in the training data, so the 97.8% is probably too optimistic.
- A clean-looking number such as `12.6.0.1` can still be a software version. None of the strings reviewed is shown to be malicious.
- If the model misses a real address, nobody may ever notice.

## Recommendation
Use the model only as a helper that suggests which records to look at first. A human analyst must decide every ambiguous or important record, and the strict address check should always run first.

## Next steps
1. Check the six escalated records against the full original export.
2. Re-test on a de-duplicated, shuffled split with more negative examples.
3. Ask the annotators what classes B, C and E mean.
