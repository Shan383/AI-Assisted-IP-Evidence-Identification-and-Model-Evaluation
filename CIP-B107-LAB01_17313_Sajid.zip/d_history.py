#!/usr/bin/env python3
"""Phase D - interpret HISTORICAL fine-tuning logs (not a new student run)."""
import pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
r = pd.read_csv("originals/result.csv"); s = pd.read_csv("originals/fine_tuning_steps.txt")
print("result.csv rows:", len(r), "| fine_tuning_steps.txt rows:", len(s), "| steps columns:", list(s.columns))
m = r.merge(s, on="step", suffixes=("_result", "_steps")); print("steps in both files:", len(m), "| max |training_loss difference|:", round((m.training_loss_result - m.training_loss_steps).abs().max(), 4), "-> the two files are NOT the same run/log" if (m.training_loss_result - m.training_loss_steps).abs().max() > 1e-6 else "-> identical")
metrics = ["classification/accuracy","classification/precision","classification/recall","classification/f1.0","classification/auroc","classification/auprc"]
print("\nnon-null counts:\n", r[["validation_loss","validation_sequence_accuracy"] + metrics].notna().sum().to_string())
nn = r.dropna(subset=["classification/accuracy"]); last = nn.iloc[-1]
print("\nfinal non-null classification row: step", int(last.step))
for m in metrics: print(f"  {m}: {last[m]:.6f}")
print("\nfirst/last training_loss:", round(r.training_loss.iloc[0],4), round(r.training_loss.iloc[-1],4),
      "| steps with training_sequence_accuracy==0 after step 100:", int(((r.step > 100) & (r.training_sequence_accuracy == 0)).sum()))
fig, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].plot(r.step, r.training_loss, lw=.8); ax[0].set_yscale("log"); ax[0].set_title("HISTORICAL training_loss vs step"); ax[0].set_xlabel("step")
for m in ["classification/accuracy","classification/precision","classification/recall","classification/f1.0"]:
    ax[1].plot(nn.step, nn[m], marker="o", ms=3, label=m.split("/")[1])
ax[1].set_title("HISTORICAL classification metrics (non-null rows only)"); ax[1].set_xlabel("step"); ax[1].legend()
plt.tight_layout(); plt.savefig("results/historical_training_curves.png", dpi=150); print("saved results/historical_training_curves.png")
