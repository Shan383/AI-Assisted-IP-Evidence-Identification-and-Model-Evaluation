#!/usr/bin/env python3
"""Phases C+E - rule baseline, majority baseline, TF-IDF+LogReg on the FIXED supplied split."""
import json, re, ipaddress, random, platform, sys
import numpy as np, pandas as pd, sklearn, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import (confusion_matrix, classification_report, accuracy_score, precision_score,
                             recall_score, f1_score, roc_auc_score, average_precision_score)
SEED = 42; random.seed(SEED); np.random.seed(SEED)
load = lambda f: [json.loads(l) for l in open("originals/" + f, encoding="utf-8")]
tr, te = load("dataset_train.jsonl"), load("dataset_test.jsonl")
def split(p):                       # prompt = "<context>;<candidate> ->"
    ctx, cand = p.rsplit(";", 1); return ctx, cand.replace("->", "").strip()
def frame(rows, name):
    d = pd.DataFrame(rows); d[["context", "candidate"]] = d.prompt.apply(lambda p: pd.Series(split(p)))
    d["y"] = (d.completion.str.strip() == "positive").astype(int); d["split"] = name; return d
TR, TE = frame(tr, "train"), frame(te, "test")

# ---- leakage check ----
ov_prompt = set(TR.prompt) & set(TE.prompt); ov_cand = set(TR.candidate) & set(TE.candidate)
print(f"LEAKAGE: {len(ov_prompt)} test prompts also in train (exact); {len(ov_cand)} candidate strings shared; "
      f"{TE.prompt.isin(TR.prompt).sum()}/{len(TE)} test rows have an exact duplicate in train")

# ---- rule-based baseline: strict IPv4 AND candidate stands alone (not glued to more digits/dots) ----
def rule(ctx, cand):
    try: ipaddress.IPv4Address(cand)
    except ValueError: return 0
    return int(bool(re.search(r"(?<![\d.])" + re.escape(cand) + r"(?!\d|\.\d)", ctx)))
TE["rule_pred"] = [rule(c, a) for c, a in zip(TE.context, TE.candidate)]

# ---- majority baseline ----
dm = DummyClassifier(strategy="most_frequent").fit(TR.context, TR.y); TE["majority_pred"] = dm.predict(TE.context)

# ---- TF-IDF (char n-grams on the whole prompt) + Logistic Regression; vectorizer fit on TRAIN only ----
vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), lowercase=False, sublinear_tf=True)
Xtr = vec.fit_transform(TR.prompt); Xte = vec.transform(TE.prompt)
clf = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=SEED).fit(Xtr, TR.y)
TE["ml_score"] = clf.predict_proba(Xte)[:, 1]; TE["ml_pred"] = (TE.ml_score >= 0.5).astype(int)

# ---- evaluation ----
def outcome(y, p): return {(1,1):"TP",(0,0):"TN",(0,1):"FP",(1,0):"FN"}[(y, p)]
res = {}
for name, col in [("majority", "majority_pred"), ("rule_regex_ipaddress", "rule_pred"), ("tfidf_logreg", "ml_pred")]:
    y, p = TE.y, TE[col]; tn, fp, fn, tp = confusion_matrix(y, p, labels=[0, 1]).ravel()
    res[name] = dict(TN=tn, FP=fp, FN=fn, TP=tp, accuracy=accuracy_score(y, p),
                     precision=precision_score(y, p, zero_division=0), recall=recall_score(y, p, zero_division=0),
                     f1=f1_score(y, p, zero_division=0))
    TE[name + "_outcome"] = [outcome(a, b) for a, b in zip(y, p)]
    print(f"\n=== {name} ==="); print(confusion_matrix(y, p, labels=[0, 1]), "(rows=actual neg/pos, cols=pred neg/pos)")
    print(classification_report(y, p, target_names=["negative", "positive"], zero_division=0))
res["tfidf_logreg"]["AUROC"] = roc_auc_score(TE.y, TE.ml_score); res["tfidf_logreg"]["AUPRC"] = average_precision_score(TE.y, TE.ml_score)
pd.DataFrame(res).T.to_csv("results/metrics_summary.csv"); print(pd.DataFrame(res).T.round(4).to_string())

TE.assign(actual=TE.y.map({1:"positive",0:"negative"}), ml_predicted=TE.ml_pred.map({1:"positive",0:"negative"}),
          rule_predicted=TE.rule_pred.map({1:"positive",0:"negative"}))\
  [["candidate","context","actual","ml_predicted","ml_score","tfidf_logreg_outcome","rule_predicted","rule_regex_ipaddress_outcome","majority_pred","majority_outcome"]]\
  .to_csv("results/predictions.csv", index_label="test_row")

# ---- charts ----
fig, ax = plt.subplots(1, 3, figsize=(12, 3.8))
for a, (n, col) in zip(ax, [("Majority", "majority_pred"), ("Rule (regex+ipaddress)", "rule_pred"), ("TF-IDF + LogReg", "ml_pred")]):
    cm = confusion_matrix(TE.y, TE[col], labels=[0, 1]); a.imshow(cm, cmap="Blues"); a.set_title(n)
    a.set_xticks([0, 1], ["neg", "pos"]); a.set_yticks([0, 1], ["neg", "pos"]); a.set_xlabel("predicted"); a.set_ylabel("actual")
    for i in range(2):
        for j in range(2): a.text(j, i, cm[i, j], ha="center", va="center", fontsize=14)
plt.tight_layout(); plt.savefig("results/confusion_matrices.png", dpi=150)

# ---- reproducibility record + imbalance counter-example ----
open("results/environment.txt", "w").write(f"python {sys.version.split()[0]}\nsklearn {sklearn.__version__}\npandas {pd.__version__}\nnumpy {np.__version__}\nmatplotlib {matplotlib.__version__}\nplatform {platform.platform()}\nseed {SEED}\n")
print("\nCOUNTER-EXAMPLE: 1000 recovered strings, 20 genuine IP evidence (2%). A model that always says 'negative' scores "
      f"{980/1000:.1%} accuracy but recall = 0/20 = 0% -> every real IP is missed.")
print("On THIS test set the always-positive majority baseline scores", f"{res['majority']['accuracy']:.1%} accuracy with 0 true negatives found.")
